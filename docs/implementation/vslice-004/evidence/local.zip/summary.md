# ADR-001 validation passed

```json
{
  "headSha": "92c30471518d86aaffdca5e70a31d59195b12922",
  "trackedChanges": false,
  "platform": "Linux-7.2.5-3-omarchy-x86_64-with-glibc2.44",
  "architecture": "x86_64",
  "rustc": "rustc 1.99.1 (58cf8f9c3 2026-10-13)",
  "cargo": "cargo 1.99.1 (5f94df478 2026-08-27)",
  "cargoComponent": "cargo-component-component 0.21.1",
  "wasmtime": "49.0.1",
  "python": "3.14.7",
  "jsonschema": "4.26.0",
  "rdflib": "7.6.0",
  "github": {
    "GITHUB_SERVER_URL": null,
    "GITHUB_REPOSITORY": null,
    "GITHUB_RUN_ID": null,
    "GITHUB_RUN_ATTEMPT": null,
    "GITHUB_SHA": null,
    "GITHUB_REF": null,
    "RUNNER_OS": null,
    "RUNNER_ARCH": null
  },
  "checks": {
    "guest-builds": "passed",
    "workspace-tests": "passed",
    "clippy": "passed",
    "contracts": "passed",
    "python-tests": "passed",
    "fmt": "passed"
  },
  "sha256": {
    "native-Cargo.lock": "e93bdaf7fbaf3f9fa3c8e104788349ef5f37f0093c7b325796c059d5a535875c",
    "guest-Cargo.lock": "4da36e512ebfe55c4d5a332d5318a8652e8ac8491fdb900c4c6e21ce7bb08b4c",
    "component.wit": "cf90e5114153e2737accd1fc7535e1e494e699ac68b4e99e8cc36c8270a204c0",
    "abi-tests.rs": "263f74a47a8daf26197f8b3e947fc51e73e05da4030ac008ea416ed4d9542c95",
    "host-adapter.rs": "a04bd4f87020d4d06e644dfc324d22f6752f57557273eae4aa543bb6344a2da2",
    "components/ipc-aggregate.wasm": "9e19c6822c0cefae293bd507beaafbeecb6332b29800ecff5617d264358528fe",
    "components/echo.wasm": "d9499a7a60a7dd7c814de67ae7d3da8aaf5e12d054b0f0555e4b67530be2233d",
    "components/integer.wasm": "871d862cd23aef8f746861c42ca01976eca453f09c3600b7efb6292d0f7d54bd",
    "components/denied-wasi.wasm": "03f3652468822b9c5439ad7c7b6c47b546f282d621279b0402c6f210587617af"
  },
  "ipcReport": "ipc-report.json"
}
```
