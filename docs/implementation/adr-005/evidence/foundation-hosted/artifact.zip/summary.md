# ADR-001 validation passed

```json
{
  "headSha": "a3011c492090c38a332f88c2809d3217a9698641",
  "trackedChanges": false,
  "platform": "Linux-6.17.0-1022-azure-x86_64-with-glibc2.39",
  "architecture": "x86_64",
  "rustc": "rustc 1.99.1 (58cf8f9c3 2026-10-13)",
  "cargo": "cargo 1.99.1 (5f94df478 2026-08-27)",
  "cargoComponent": "cargo-component-component 0.21.1",
  "wasmtime": "49.0.1",
  "python": "3.11.17",
  "jsonschema": "4.26.0",
  "rdflib": "7.6.0",
  "github": {
    "GITHUB_SERVER_URL": "https://github.com",
    "GITHUB_REPOSITORY": "srmr-net/intellectual-workbench-bootstrap-v0.1",
    "GITHUB_RUN_ID": "40538999368",
    "GITHUB_RUN_ATTEMPT": "1",
    "GITHUB_SHA": "a3011c492090c38a332f88c2809d3217a9698641",
    "GITHUB_REF": "refs/pull/9/merge",
    "RUNNER_OS": "Linux",
    "RUNNER_ARCH": "X64"
  },
  "checks": {
    "guest-builds": "passed",
    "workspace-tests": "passed",
    "clippy": "passed",
    "contracts": "passed",
    "python-tests": "passed",
    "fmt": "passed"
  },
  "sha256": {
    "native-Cargo.lock": "e93bdaf7fbaf3f9fa3c8e104788349ef5f37f0093c7b325796c059d5a535875c",
    "guest-Cargo.lock": "4da36e512ebfe55c4d5a332d5318a8652e8ac8491fdb900c4c6e21ce7bb08b4c",
    "component.wit": "cf90e5114153e2737accd1fc7535e1e494e699ac68b4e99e8cc36c8270a204c0",
    "abi-tests.rs": "263f74a47a8daf26197f8b3e947fc51e73e05da4030ac008ea416ed4d9542c95",
    "host-adapter.rs": "a04bd4f87020d4d06e644dfc324d22f6752f57557273eae4aa543bb6344a2da2",
    "components/ipc-aggregate.wasm": "a7a475e540c7193511053aceb9a3e691a0c53ddf28624a3c4d012921994f9627",
    "components/echo.wasm": "3957fa6c0b3a7b1d621661e90252a277ffef0120fda18f0e63e9eadd747b2aec",
    "components/integer.wasm": "b1dda424bf8cc28936ad4e1610d511def78deb3922bfba2047ee8ec33a375494",
    "components/denied-wasi.wasm": "03f3652468822b9c5439ad7c7b6c47b546f282d621279b0402c6f210587617af"
  },
  "ipcReport": "ipc-report.json"
}
```
